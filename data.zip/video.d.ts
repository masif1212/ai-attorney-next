/// <reference types="next-video/video-types/global" />
